# Copyright 2018 Canonical Ltd.
# Licensed under the LGPLv3, see LICENCE.txt file for details.

"""Application custom exceptions."""


class AppError(Exception):
    """An error occurred while running the application."""
